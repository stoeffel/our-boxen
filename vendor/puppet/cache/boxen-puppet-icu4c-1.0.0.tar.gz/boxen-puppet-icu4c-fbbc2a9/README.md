# icu4c Puppet Module for Boxen

## Usage

```puppet
include icu4c
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib

## Developing

Write code.

Run `script/cibuild`.
