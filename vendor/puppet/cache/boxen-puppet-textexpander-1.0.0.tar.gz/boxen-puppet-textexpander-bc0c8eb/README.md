# TextExpander
[TextExpander](http://www.smilesoftware.com/TextExpander/) saves your fingers
and your keyboard, expanding custom keyboard shortcuts into frequently-used
text and pictures.

## Usage

```puppet
include textexpander
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
