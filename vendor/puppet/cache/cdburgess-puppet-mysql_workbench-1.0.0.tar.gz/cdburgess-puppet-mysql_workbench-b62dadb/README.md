# MySQL Workbench Puppet Module for Boxen

## Usage

```puppet
include mysql_workbench
```

## Required Puppet Modules

None.

## Latest Version
1.0.0