# Google Drive Sync Puppet Module for Boxen

A Google Drive Sync module for Boxen, mmmkay?

## Usage

```puppet
include googledrive
```

## Required Puppet Modules

* `boxen`
