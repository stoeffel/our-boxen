# Sublime Text 2 Puppet Module for Boxen

## Usage

```puppet
include sublime_text_2
sublime_text_2::package { 'Emmet':
  source => 'sergeche/emmet-sublime'
}
```

## Required Puppet Modules

None.
