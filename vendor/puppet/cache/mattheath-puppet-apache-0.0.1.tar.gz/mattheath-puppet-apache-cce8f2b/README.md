# Apache Puppet Module for Boxen

## Usage

```puppet
include apache
```

## Required Puppet Modules

* boxen
* stdlib
